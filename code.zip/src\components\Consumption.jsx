import React from 'react';

const Consumption = () => {
    return (
        <div>
            <div className='w-36 h-8 bg-lightGreen rounded-md flex justify-center items-center text-xl text-rgbaHeader'></div>
        </div>
    );
};

export default Consumption;
export const actionTypes = {
    GO_TO_CALC: "GO_TO_CALC",
}
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const About = () => {
    return (
        <div>
            <Header />
            <div className="bg-[#FFE6C7]" id='about'>
                <div className=''>
                    <div className='container  mx-auto p-32'>

                    </div>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default About;
import React from 'react';

const ReduceEnergy = () => {
    return (
        <div>
            reduce ReduceEnergy
        </div>
    );
};

export default ReduceEnergy;
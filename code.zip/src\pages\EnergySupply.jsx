import React from 'react';

const EnergySupply = () => {
    return (
        <div>
            Energysupply
        </div>
    );
};

export default EnergySupply;
import React from 'react';

const EnergySaving = () => {
    return (
        <div>
            EnergySaving
        </div>
    );
};

export default EnergySaving;
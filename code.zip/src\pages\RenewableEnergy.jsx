import React from 'react';

const RenewableEnergy = () => {
    return (
        <div>
            RenewableEnergy
        </div>
    );
};

export default RenewableEnergy;